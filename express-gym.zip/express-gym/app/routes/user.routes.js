module.exports = (app) => {
    var router = require("express").Router();
    const allUserController = require("../controller/user.controller");
    router.post("/newUser", allUserController.newUser);
    router.post("/validate",allUserController.validateUser)
    router.get("/getUser/:email",allUserController.fetchUserDetail)
    router.post("/:id",allUserController.updateAllUsers)
    router.delete("/:id",allUserController.deleteAllUsers)
    app.use("/user", router);
  };
  