const nodemailer = require("nodemailer");
module.exports = {
  blockedMailMiddleware: async (userDetails) => {
    const transporter = nodemailer.createTransport({
      service: "hotmail",
      auth: {
        user: "Jeevap@outlook.in",
        pass: "jeeva@2000",
      },
    });
    const mailOptions = {
      from: "Jeevap@outlook.in",
      to: userDetails.email,
      subject: "Workout Plan",
      html: "<h1>7-Day Bodybuilding Workout Chart:</h1><br><h2>Day 1: Chest & Triceps</h2><br><ol><li>Bench Press</li><li>Incline Dumbbell Press</li><li>Tricep Dips</li><li>Tricep Pushdowns</li></ol><br><h2>Day 2: Back & Biceps</h2><br><ol><li>Deadlifts</li><li>Lat Pulldowns</li><li>Barbell Rows</li><li>Bicep Curls</li></ol><br><h2>Calorie chart</h2><br><ul><li><strong>Breakfast: </strong><p>400-500 calories (e.g., eggs, whole-grain toast, and fruit)</p></li><li><strong>Snack: </strong><p>200-300 calories (e.g., Greek yogurt with nuts)</p></li><li><strong>Lunch: </strong><p>500-600 calories (e.g., grilled chicken, quinoa, and vegetables)</p></li><li><strong>Snack: </strong><p>200-300 calories (e.g., protein shake or a piece of fruit)</p></li><li><strong>Dinner: </strong><p>600-700 calories (e.g., salmon, sweet potato, and broccoli)</p></li><li><strong>Snack (if needed): </strong><p>100-200 calories (e.g., a handful of almonds)</p></li></ul><br><br><p>Ensure you stay hydrated throughout the day and adjust portions based on your individual needs and goals. This is a basic guideline, and it's crucial to tailor it to your specific requirements and monitor your progress.</p>",
    };
    transporter.sendMail(mailOptions, async (error, info) => {
      if (error) {
        return "Failed to send mail";
      } else {
        console.log("Email sent: " + info.response);
        return "mail sent successfully";
      }
    });
  },
}





"<h1>7-Day Bodybuilding Workout Chart:</h1><br><h2>Day 1: Chest & Triceps</h2><br><ol><li>Bench Press</li><li>Incline Dumbbell Press</li><li>Tricep Dips</li><li>Tricep Pushdowns</li></ol><br><h2>Day 2: Back & Biceps</h2><br><ol><li>Deadlifts</li><li>Lat Pulldowns</li><li>Barbell Rows</li><li>Bicep Curls</li></ol><br><h2>Calorie chart</h2><br><ul><li><strong>Breakfast: </strong><p>400-500 calories (e.g., eggs, whole-grain toast, and fruit)</p></li><li><strong>Snack: </strong><p>200-300 calories (e.g., Greek yogurt with nuts)</p></li><li><strong>Lunch: </strong><p>500-600 calories (e.g., grilled chicken, quinoa, and vegetables)</p></li><li><strong>Snack: </strong><p>200-300 calories (e.g., protein shake or a piece of fruit)</p></li><li><strong>Dinner: </strong><p>600-700 calories (e.g., salmon, sweet potato, and broccoli)</p></li><li><strong>Snack (if needed): </strong><p>100-200 calories (e.g., a handful of almonds)</p></li></ul><br><br><p>Ensure you stay hydrated throughout the day and adjust portions based on your individual needs and goals. This is a basic guideline, and it's crucial to tailor it to your specific requirements and monitor your progress.</p>"