const db = require("../models");
const User = db.customer;
require("dotenv").config();
const middleware=require('../middleware/mail.middleware')
exports.newUser = async (req, res, next) => {
  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email,
      phoneNumber:req.body.phoneNumber,
      password:req.body.password
    });
    user
      .save(user)
      .then((data) => {
        res.send(data);
      })
      .catch((err) => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the users.",
        });
      });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while creating the users.",
    });
  }
  
};
exports.fetchUserDetail = async (req, res) => {
  try {
    const users = await User.findOne({
      email:req.params.email
    })
    res.status(200).json({
      status: 1,
      message: "Successfully fetched User Profile Details",
      data:users
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
exports.validateUser = async (req, res) => {
  try {
    const users = await User.findOne({
      email:req.body.email
    })
    if(users.password==req.body.password){
      res.status(200).json({
        data:users,
        massage:true
      });
    }
    else{
      res.status(200).json({
        massage:false
      });
    }
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
exports.updateAllUsers = async (req, res) => {
  try {
    const id = req.params.id
    let userDetail=await User.findById(id)
    userDetail.couserDetails.push(req.body.course)
    const users = await User.findByIdAndUpdate(id,userDetail)
    const a=await middleware.purcahseConfirmationMailMiddleware(userDetail)
    middleware.workoutPlanMailMiddleware(userDetail)
    res.status(200).json({
      status: 1,
      message: "Successfully purchased the courses"
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
exports.deleteAllUsers = async (req, res) => {
  try {
    const id = req.params.id
    const users = await User.deleteOne({_id:id})
    res.status(200).json({
      status: 1,
      message: "Successfully fetched User Profile Details",
      allUser: users,
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};

