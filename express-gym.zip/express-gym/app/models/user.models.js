module.exports = (mongoose) => {
    const Course = mongoose.model(
      "course",
      mongoose.Schema(
        {
            image:{type:String},
            alt:{type:String}, 
            title:{type:String}, 
            courseFee:{type:Number}, 
        },
        { timestamps: true },
      ),
    );
    return Course;
  };
  