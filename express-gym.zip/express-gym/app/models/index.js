const mongoose = require("mongoose");

mongoose.Promise = global.Promise;

const db = {};

db.mongoose = mongoose;
db.course = require("./user.models")(mongoose);
db.customer = require("./customer.model")(mongoose);
module.exports = db;
