module.exports = (mongoose) => {
    const Customer = mongoose.model(
      "customer",
      mongoose.Schema(
        {
            name:{type:String},
            password:{type:String}, 
            email:{type:String}, 
            phoneNumber:{type:String},
            couserDetails:[], 
            mailDays:[]
        },
        { timestamps: true },
      ),
    );
    return Customer;
  };
  